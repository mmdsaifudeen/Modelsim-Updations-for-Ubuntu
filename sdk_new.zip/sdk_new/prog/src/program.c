#include "xparameters.h"
#include "xgpio.h"
#include "xscugic.h"
#include "xil_exception.h"
#include "xil_printf.h"
#include "xil_io.h"
#include <stdio.h>
#include "platform.h"
// Parameter definitions
#define BTNS_DEVICE_ID		XPAR_AXI_GPIO_0_DEVICE_ID



 int rt;
XGpio  BTNInst;




//----------------------------------------------------
// MAIN FUNCTION
//----------------------------------------------------
int main (void)
{

	init_platform();

  int status;

  xil_printf("set\n\r");
  //----------------------------------------------------
  // INITIALIZE THE PERIPHERALS & SET DIRECTIONS OF GPIO
  //----------------------------------------------------

  status = XGpio_Initialize(&BTNInst, BTNS_DEVICE_ID);
  if(status != XST_SUCCESS) return XST_FAILURE;


  // Set all buttons direction to inputs
  XGpio_SetDataDirection(&BTNInst, 1, 0x0);
  if(status != XST_SUCCESS) return XST_FAILURE;
  while(1)
      {
      scanf("%d",&rt);
      if(rt==1)
      {
       XGpio_DiscreteWrite(&BTNInst, 1, 1);
      xil_printf("%d  reset\n\r",rt);
      }
      else
      {
           XGpio_DiscreteWrite(&BTNInst, 1, 0);
           xil_printf("%d    not reset\n\r",rt);
          }
      }
      cleanup_platform();

  return 0;
}


